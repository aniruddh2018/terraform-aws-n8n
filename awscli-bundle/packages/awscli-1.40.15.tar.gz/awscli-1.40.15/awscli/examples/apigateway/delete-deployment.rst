**To delete a deployment in an API**

Command::

  aws apigateway delete-deployment --rest-api-id 1234123412 --deployment-id a1b2c3
